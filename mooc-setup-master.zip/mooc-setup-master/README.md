# mooc-setup
Information for setting up for the Spark MOOC
